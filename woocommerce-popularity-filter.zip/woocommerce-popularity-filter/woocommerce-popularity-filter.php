<?php
/**
* Plugin Name: WooCommerce Popularity Filter
* Plugin URI: https://turnuphosting.com/web-design
* Description: A plugin to filter and sort WooCommerce products by popularity.
* Version: 1.0
* Author: TurnUpHosting
* Author URI: https://turnuphosting.com
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Add custom sorting options
add_filter('woocommerce_get_catalog_ordering_args', 'custom_woocommerce_get_catalog_ordering_args');
add_filter('woocommerce_default_catalog_orderby_options', 'custom_woocommerce_catalog_orderby');
add_filter('woocommerce_catalog_orderby', 'custom_woocommerce_catalog_orderby');

function custom_woocommerce_get_catalog_ordering_args($args) {
    if (isset($_GET['orderby'])) {
        switch ($_GET['orderby']) {
            case 'popularity':
                $args['orderby'] = 'meta_value_num';
                $args['order'] = 'desc';
                $args['meta_key'] = 'total_sales';
                break;
        }
    }
    return $args;
}

function custom_woocommerce_catalog_orderby($sortby) {
    $sortby['popularity'] = __('Sort by popularity', 'woocommerce');
    return $sortby;
}

add_action('pre_get_posts', 'custom_pre_get_posts');

function custom_pre_get_posts($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_search() && !isset($_GET['orderby'])) {
        $query->set('meta_key', 'total_sales');
        $query->set('orderby', 'meta_value_num');
        $query->set('order', 'desc');
    }
}
